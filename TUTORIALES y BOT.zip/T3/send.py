#!/usr/bin/env python
import pika

#Conexión al servidor RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

#Creación de la cola
channel.queue_declare(queue='resu')
channel.queue_declare(queue='visit')
ingress = input("Ingrese palabra a buscar: ")

#Publicación del mensaje
channel.basic_publish(exchange='',
                      routing_key='resu',
                      body=ingress)

channel.basic_publish(exchange='',
                      routing_key='visit',
                      body=ingress)

print("Realizando busqueda de", ingress, "\n")

connection.close()

